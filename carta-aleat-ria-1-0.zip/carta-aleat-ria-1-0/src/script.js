var form = document.getElementById("formulario");
var campo = document.getElementById("campo");

form.addEventListener("submit", function (e) {
  if (campo.value == 1) {
    alert("msg 1");
  } else if (campo.value == 2) {
    alert("msg 2");
  } else if (campo.value == 3) {
    alert("msg 3");
  } else if (campo.value == 4) {
    alert("msg 4");
  } else if (campo.value == 5) {
    alert("msg 5");
  } else if (campo.value == 6) {
    alert("msg 6");
  } else if (campo.value == 7) {
    alert("msg 7");
  } else if (campo.value == 8) {
    alert("msg 8");
  } else if (campo.value == 9) {
    alert("msg 9");
  } else if (campo.value == 0) {
    alert("msg 0");
  } else {
    alert("digite um número de 0 a 9");
  }
  e.preventDefault();
});
